import os, datetime
import psycopg2
import psycopg2.extras

from flask import Flask, render_template, request
app = Flask(__name__)
date = {'year' : "2016", "month" : "September", "dayOfWeek" : "Saturday", 'day' : '3'}
past = False
if datetime.datetime.today() > datetime.datetime(2016, 9 , 3):
    past = True
thenames = ['Nathan Woodhead','Heather Burgess']

regesteredGuests = [{'Name' : 'Nathan Woodhead', 'Phone' : 5408548888, 'Address' : "301 cracked street",'numGuests' : 10}]
def connectToDB():
#  connectionString = 'dbname=music user=postgres password=kirbyk9 host=localhost'
  connectionString = 'dbname=rsvplist user=nathan password=0328940 host=localhost'
  print connectionString
  try:
    return psycopg2.connect(connectionString)
  except:
    print("Can't connect to database")

@app.route('/')
def mainIndex():
	return render_template('index.html',date=date, past=past)
	
@app.route('/bridal')
def apage():
    return render_template('bridalParty.html')

@app.route('/countdown')
def count():
    
    diff = datetime.datetime(2016, 9, 3) - datetime.datetime.today()
    days = diff.days
    return render_template('countdown.html', dayz=days, date=date, past=past)
    
@app.route('/registry')
def stuff():
    want = ['http://store.ssgtactical.com/product.iwi-us-inc-tavor-semi-automatic-9mm-17-black-bullpup-1-mag-32rd-adjustable-sights-tsb17-9-34', 'http://store.ssgtactical.com/product.century-arms-international-922r-fury-12-gauge-semi-auto-1-10rd-us-24', 'http://store.ssgtactical.com/product.kimber-solo-carry-9mm-1039']
    return render_template('registry.html', iwant = want)
    
@app.route('/rsvp', methods=['POST', 'GET'])
def rsvp():
  conn = connectToDB()
  cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
  if request.method == 'POST':
    try:
      cur.execute("""INSERT INTO list (name, phone, address, numberofguests) 
       VALUES (%s, %s, %s, %s);""",
       (request.form['name'], request.form['phone'], request.form['address'], request.form['num']) )
      
      
    except:
      print "Error inserting into list"
      conn.rollback()
        
    conn.commit()
  try:
    cur.execute("select name from list")
    
  except:
    print("Error executing select")
  results = cur.fetchall()
  print "FACTORY"
  print results
  return render_template('rsvp.html', guests=results)
  
# start the server
if __name__ == '__main__':
    app.run(host=os.getenv('IP', '0.0.0.0'), port =int(os.getenv('PORT', 8080)), debug = True)
